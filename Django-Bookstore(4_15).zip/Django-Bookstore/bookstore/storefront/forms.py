
from django import forms

from .models import Customers

class CustomerRegForm(forms.ModelForm):
    class Meta:
        #
        #
        password = forms.CharField(widget=forms.PasswordInput())

        cardnumber = forms.CharField(widget=forms.PasswordInput())
        #


        model = Customers
        fields = ['first_name', 'last_name', 'email', 'phone', 'address', 'state', 'city', 'zip_code', 'cardtype', 'cardnumber', 'password']
        widgets = {'password':forms.PasswordInput(),
                   'cardnumber':forms.PasswordInput(),}

class CustomerLoginForm(forms.ModelForm):
    class Meta:

        email = forms.CharField()
        password = forms.CharField(widget=forms.PasswordInput())

        model = Customers
        fields = ['email','password']
        widgets = {'password':forms.PasswordInput(),}
