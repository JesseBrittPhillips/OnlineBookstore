from django.shortcuts import render, redirect

from .models import Customers

from .forms import CustomerRegForm, CustomerLoginForm

# Create your views here.
def customer_reg_view(request):
    form = CustomerRegForm(request.POST or None)
    if form.is_valid():
        form.save()

    context = {
        'form': form
    }
    return render(request, "storefront/html/registration.html", context)

def customer_reg_complete_view(request):
    context = {}
    return render(request, "storefront/html/registrationComplete.html", context)

def customer_login_view(request):
    x = 0
    y = ""
    form = CustomerLoginForm(request.POST or None)
    if form.is_valid():
        user = form.save(commit=False)
        for cust in Customers.objects.raw('SELECT * FROM bookstore.customers'):
            if(cust.email == user.email):
                if(cust.password == user.password):
                    y=""
                    x=1
                else:
                    y="please enter the correct email/password"
            else:
                y = "please enter the correct email/password"
    context = {
        'form': form,
        'x':x,
        'y':y,
    }
    if(x):
        return redirect('/loggedin')
    else:
        return render(request, "storefront/html/login.html", context)

def forgot_view(request):
    x = 0
    form = CustomerLoginForm(request.POST or None)
    if form.is_valid():
        user = form.save(commit=False)
        for cust in Customers.objects.raw('SELECT * FROM bookstore.customers'):
            if (cust.email == user.email):
                cust.password = user.password
                cust.save()
                x=1

    context = {
        'form': form,
        'x': x
    }
    if (x):
        return redirect('/login')
    else:
        return render(request, "storefront/html/forgot.html", context)

def home_view(request):
    context = {}
    return render(request, "storefront/html/home.html", context)

def loggedin_view(request):
    context = {}
    return render(request, "storefront/html/loggedin.html", context)

def edit_view(request):
    x = 0
    y = ""
    form = CustomerLoginForm(request.POST or None)
    first = ""
    last = ""
    address = ""
    password = ""
    cardtype = ""


    if form.is_valid():
        user = form.save(commit=False)
        for cust in Customers.objects.raw('SELECT * FROM bookstore.customers'):
            if(cust.email == user.email):
                if(cust.password == user.password):
                    y=""
                    x=1

                else:
                    y="please enter the correct email/password"
            else:
                y = "please enter the correct email/password"

    context = {
        'form': form,
        'x':x,
        'y':y,
    }
    if(x):
        return redirect('/loggedin')
    else:
        return render(request, "storefront/html/login.html", context)